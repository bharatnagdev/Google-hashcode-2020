<?php
// Define input/output file paths
$inFilePath = "../inputs/";
$outFilePath = "../outputs/";

// Define input file names
$fileNames = ["a_example", "b_small", "c_medium", "c_medium", "d_quite_big", "e_also_big"];

foreach ($fileNames as $value) {
    readWriteData($value);
}

/**
 * read from data and then apply logic for calculation and then write final output into file
 * @param string $fileName
 */
function readWriteData($fileName) {
    
    // use and define global variable used in function
    global $inFilePath, $outFilePath;
    echo "<br>------------------------------------------------------------<br>";
    echo "Input File: " . $fileName;
    echo "<br>------------------------------------------------------------<br>";
    
    // try to open file 
    $fh = fopen($inFilePath . $fileName . '.in', 'r');
    if (!$fh) {
        echo "Unable to open input file";
        return 0;
    }
    
    // Readfrom file, store into array, close the file
    $fileData = [];
    while ($line = fgets($fh)) {
        $fileData[] = $line;
    }
    fclose($fh);
    
    // check that we have got proper 2 lines from the file
    if (count($fileData) > 2) {
        return 0;
    }

    // seperate the inputlines and print input file data
//    echo "Input File Data <br>";
//    echo $fileData[0] . "<br>";
//    echo $fileData[1] . "<br>";
    
    $noOfChoices = explode(" ", $fileData[0])[1];
    $maxOrder = explode(" ", $fileData[0])[0];
    $sizes = explode(" ", $fileData[1]);
    
    // call the main logic function forget solution
    $finalIndexList = solutionLogic($maxOrder, $sizes);
    
    // print got output and write into file
//    echo "Output File Data <br>";
//    echo count($finalIndexList) . "<br>";
//    echo implode(" ", $finalIndexList) . "<br>";
    
    $fh = fopen($outFilePath . $fileName . '.out', 'w');
    if (!$fh) {
        echo "Unable to open output file";
        return 0;
    }
    fwrite($fh, (count($finalIndexList) . "\n" . implode(" ", $finalIndexList)));
    fclose($fh);
}

/**
 * The main solution & logic for find the set of keys that we can order max or near to max 
 * @param int $maxOrder
 * @param array $sizes
 */
function solutionLogic($maxOrder, $sizes) {
    
    // declare and initialize variables with default value
    $mainList = $tempList = $tempValList = [];
    $mainTotal = $tempTotal = 0;
    $fullsize = count($sizes);
    
    echo $fullsize . '<br>';
    // loop untill we couldn't got result
    while((count($tempList) > 0 && $tempList[0] != 0) || count($tempList) == 0){

        // declare and  initialize the temp variables
        $fullsize = $fullsize - 1;

        // inner loop for actual logic for compare and calculate the sum from sizes
        for($j = $fullsize; $j >= 0; $j--) {
            
            // calculate the temp sum from previous temp sum and current value of list
            $totTmp = $tempTotal + $sizes[$j];
            
            if ($totTmp == $maxOrder) { // if temp total and max order same we got solution and no need to further check
               $tempTotal = $totTmp; // store tmp total into temp total for next itteration calculation
               $tempList[] = $j; // add current index into temp list
               $tempValList[] = $sizes[$j]; // add current value into temp value list
               break;
            } elseif ($totTmp < $maxOrder) { // if temp total is less than max order 
               $tempTotal = $totTmp; // store tmp total into temp total for next itteration calculation
               $tempList[] = $j; // add current index into temp list
               $tempValList[] = $sizes[$j]; // add current value into temp value list
               continue; 
            } elseif ($totTmp > $maxOrder) { // if temp total is less than max order, we need to continue for next itteration
               continue; 
            }
        }
        
        // if main total is less than temp total, we need to store temp total into main total and temp list into main list
        if ($mainTotal < $tempTotal) {
            $mainTotal = $tempTotal;
            $mainList = $tempList;
        }
        
        // if main total and max order same we got solution and no need to further check
        if ($mainTotal == $maxOrder) {
            break ;
        }
        
        // check temp value list size not 0
        // minus last value added total from temp total
        if (count($tempValList) != 0) {
            $lastVal = array_pop($tempValList);
            $tempTotal = $tempTotal - $lastVal;
        }
        
        // check temp list size not 0
        // minus last value added total from temp total
        if (count($tempList) != 0) {
            $lastIndex = array_pop($tempList);
            $fullsize = $lastIndex;
        }
        
        // check temp list is empty and index variable is also empty or not?
        if (count($tempList) == 0 && $fullsize == 0) {
            break;
        }
    }
    echo $mainTotal . "<br>";
    // sorting the main list as we get solution in descending order
    sort($mainList);
    
    // return the main list
    return $mainList;
}
?>

