let fs = require("fs");
let readline = require('readline');
// Define input/output file paths
let inFilePath = "../inputs/"
let outFilePath = "../outputs/"

// Define input file names
let fileNames = ["a_example", "b_small", "c_medium", "c_medium", "d_quite_big", "e_also_big"]

for (let value of fileNames) {
  try {
    readWriteData(value)
  } catch(ex) {
    console.log(ex)
  }
}

/**
 * The main solution & logic for find the set of keys that we can order max or near to max 
 * @param int $maxOrder
 * @param array $sizes
 */
async function solutionLogic(maxOrder, sizes) {
    
    // declare and initialize variables with default value
    let mainList = []
    let mainTotal = 0
    let tempList = []
    let tempValList = []
    let tempTotal = 0
    let fullsize = sizes.length
    // loop through the array in reverse order
    
    while((tempList.length > 0 && tempList[0] != 0) ||tempList.length == 0){
        
        // declare and  initialize the temp variables
        fullsize = fullsize - 1
        
        // inner loop for actual logic for compare and calculate the sum from sizes
        for(let j = fullsize; j >= 0; j--) {
            
            // calculate the temp sum from previous temp sum and current value of list
            let totTmp = tempTotal + parseInt(sizes[j])
            
            if (totTmp == maxOrder) { // if temp total and max order same we got solution and no need to further check
               tempTotal = totTmp // store tmp total into temp total for next itteration calculation
               tempValList.push(parseInt(sizes[j]))
               tempList.push(j) // add current index into temp list
               break;
            } else if (totTmp < maxOrder) { // if temp total is less than max order 
               tempTotal = totTmp // store tmp total into temp total for next itteration calculation
               tempValList.push(parseInt(sizes[j]))
               tempList.push(j) // add current index into temp list
               continue; 
            } else if (totTmp > maxOrder) { // if temp total is less than max order, we need to continue for next itteration
               continue; 
            }
        }
        
        // if main total is less than temp total, we need to store temp total into main total and temp list into main list
        if (mainTotal < tempTotal) {
            mainTotal = tempTotal
            mainList = []
            for(let value of tempList) {
              mainList.push(value)
            }
        }
        // if main total and max order same we got solution and no need to further check
        if (mainTotal == maxOrder) {
            break;
        }
        if(tempValList.length != 0){
          let lastVal = tempValList.pop() 
          tempTotal = tempTotal - lastVal
        }
        if(tempList.length != 0){
          let lastIndex = tempList.pop()
          fullsize = lastIndex
        }
        if(tempList.length == 0 && (fullsize == 0)){
          break;
        }

      
    }
      console.log(mainTotal)
      // return the main list
      return mainList
}

/**
 * read from data and then apply logic for calculation and then write final output into file
 * @param string $fileName
 */
async function readWriteData(fileName) {
    
  // use and define global variable used in function
  let fileData = []
  console.log("\n------------------------------------------------------------\n")
  console.log("Input File: " + fileName)
  console.log("\n------------------------------------------------------------\n")

  readData(fileName).then((fileData) => {
    // check that we have got proper 2 lines from the file
    if (fileData.length > 2) {
      return 0
    }

    // seperate the inputlines and print input file data
    // console.log("Input File Data \n")
    // console.log(fileData[0] + "\n")
    // console.log(fileData[1] + "\n")
    
    let noOfChoices = parseInt(fileData[0].split(' ')[1])
    let maxOrder = parseInt(fileData[0].split(' ')[0])    
    let sizes = fileData[1].split(' ')
    // call the main logic function forget solution
    solutionLogic(maxOrder, sizes).then((finalIndexList) => {
      // print got output and write into file
      finalIndexList.sort()
      console.log("Output File Data \n")
      // console.log(finalIndexList.length + "\n")
      // console.log(finalIndexList.join(" ") + "\n")
      
      fs.writeFile(outFilePath + fileName + '.out', (finalIndexList.length + "\n" + finalIndexList.join(" ")) , (err) => {
          if (err) {
              console.error("Unable to open output file")
              return 0
          }
      })
    }).catch(err => {
      console.error(err)
    })
  }).catch(err => {
    console.error(err)
  })
}

async function readData(fileName){
  // try to open file 
    let readStream = fs.createReadStream(inFilePath + fileName + '.in')
    let fileData = []
    let rl = readline.createInterface({
      input: readStream
    });
    for await (let line of rl) {
      fileData.push(line)
    }
    if (fileData.length > 0) {
        return fileData;
    }
}